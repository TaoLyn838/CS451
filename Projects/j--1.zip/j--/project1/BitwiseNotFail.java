import java.lang.System;

public class BitwiseNotFail {
    public static void main(String[] args) {
        System.out.println(~42);
        System.out.println(~"42");
    }
}
